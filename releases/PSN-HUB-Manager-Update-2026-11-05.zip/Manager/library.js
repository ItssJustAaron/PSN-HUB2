/* Manager library UI. File transfers use the native PS5 Manager API. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const state = {catalog: null, page: 0, pageSize: 24, groups: [], transfer: null, manager: false, preview: false, firmware: '', firmwareSource: '', showIncompatible: false};
  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function action(text, fn, className) {
    const node = element('button', text, className);
    node.type = 'button'; node.addEventListener('click', fn); return node;
  }
  function startLeafBackground() {
    // Canvas vectors keep the background lightweight and independent of artwork downloads.
    if (!document.body || !window.requestAnimationFrame) return;
    const canvas = element('canvas'); canvas.id = 'leaf-background';
    canvas.setAttribute('aria-hidden', 'true'); document.body.prepend(canvas);
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    let width = 0, height = 0, frame = 0, last = 0, leaves = [];
    const tips = [[-25,5],[-30,-14],[-18,-33],[0,-47],[18,-33],[30,-14],[25,5]];
    function leaf() {
      ctx.fillStyle = '#39ff14';
      for (const [tx,ty] of tips) {
        const dx = tx, dy = ty - 14, length = Math.hypot(dx,dy), nx = -dy/length, ny = dx/length;
        const breadth = Math.abs(tx) > 24 ? 5 : 6;
        ctx.beginPath(); ctx.moveTo(0,14);
        for (let side = 1; side >= -1; side -= 2) {
          for (let i = 1; i <= 12; i++) {
            const t = side === 1 ? i/12 : 1-i/12;
            const spread = Math.sin(Math.PI*t)*breadth*(i%2 ? 1 : .55)*side;
            ctx.lineTo(dx*t+nx*spread,14+dy*t+ny*spread);
          }
        }
        ctx.closePath(); ctx.fill();
      }
      ctx.fillRect(-1,12,2,18);
    }
    function paint(time) {
      const dt = last ? Math.min((time-last)/1000,.05) : 0; last = time;
      ctx.clearRect(0,0,width,height);
      for (const item of leaves) {
        if (!reduced.matches) {
          item.y -= item.speed*dt; item.angle += item.spin*dt;
          if (item.y < -80) { item.y = height+80; item.x = Math.random()*width; }
        }
        ctx.save(); ctx.translate(item.x+Math.sin(item.y/140)*12,item.y); ctx.rotate(item.angle); ctx.scale(item.scale,item.scale);
        ctx.globalAlpha = item.alpha; leaf(); ctx.restore();
      }
      frame = !reduced.matches && !document.hidden ? window.requestAnimationFrame(paint) : 0;
    }
    function resume() {
      window.cancelAnimationFrame(frame); frame = 0; last = 0;
      if (!document.hidden) paint(0);
    }
    function resize() {
      width = window.innerWidth; height = window.innerHeight;
      const ratio = Math.min(window.devicePixelRatio || 1,1.5);
      canvas.width = Math.round(width*ratio); canvas.height = Math.round(height*ratio); ctx.setTransform(ratio,0,0,ratio,0,0);
      leaves = Array.from({length:width<700?10:20},()=>({x:Math.random()*width,y:Math.random()*height,scale:.25+Math.random()*.45,angle:Math.random()*Math.PI*2,speed:10+Math.random()*16,spin:(Math.random()-.5)*.18,alpha:.22+Math.random()*.35}));
      resume();
    }
    window.addEventListener('resize',resize); document.addEventListener('visibilitychange',resume);
    window.addEventListener('pagehide',()=>window.cancelAnimationFrame(frame));
    window.addEventListener('pageshow',resume);
    if (reduced.addEventListener) reduced.addEventListener('change',resume); else reduced.addListener(resume);
    resize();
  }
  function storeRead(key, fallback) { try { return JSON.parse(localStorage.getItem('psnhub.' + key)) || fallback; } catch (_) { return fallback; } }
  function storeWrite(key, value) { try { localStorage.setItem('psnhub.' + key, JSON.stringify(value)); } catch (_) { $('catalog-status').textContent = 'Browser storage unavailable; favourites and history will last only this visit.'; } }
  const consoleKey = 'firmware:' + location.host;
  let manualFirmware = storeRead(consoleKey, '');
  const ps5Version = typeof navigator !== 'undefined' && /PlayStation 5\/(\d+\.\d{2})/.exec(navigator.userAgent);
  function firmwareValue(value) { return typeof value === 'string' && /^\d{1,2}\.\d{2}$/.test(value.trim()) ? Number(value.trim().split('.')[0]) + '.' + value.trim().split('.')[1] : ''; }
  function compatibility(item, version = state.firmware) {
    const versions = item.firmware && Object.values(item.firmware).flat();
    if (!version || (item.firmwareConditional || []).includes(version)) return 'unknown';
    if (versions && versions.length) return versions.includes(version) ? 'compatible' : 'incompatible';
    const ranges = item.firmwareRanges;
    if (!ranges || !ranges.length) return 'unknown';
    return ranges.some(range => compareVersions(version,range.min)>=0 && compareVersions(version,range.max)<=0) ? 'compatible' : 'incompatible';
  }
  function selectFirmware(reported) {
    const detected = firmwareValue(reported);
    state.firmware = detected || (ps5Version && firmwareValue(ps5Version[1])) || firmwareValue(manualFirmware);
    state.firmwareSource = detected ? 'Reported by console' : ps5Version ? 'Detected from PS5 browser' : state.firmware ? 'Manually selected for this console' : 'Not detected';
    updateFirmwareUI(); renderCompatibility();
  }
  function firmwareControls() {
    const panel = element('div', undefined, 'firmware-settings'), row = element('div', undefined, 'row');
    const badge = element('span', '', 'badge'); badge.id = 'firmware-badge';
    const label = element('label', 'Console firmware '), input = element('input'); input.type = 'text'; input.id = 'console-firmware'; input.placeholder = 'e.g. 10.01'; input.inputMode = 'decimal'; input.value = firmwareValue(manualFirmware); label.append(input);
    const apply = action('Set firmware', () => {
      const version = firmwareValue(input.value);
      if (input.value.trim() && !version) { $('firmware-help').textContent = 'Enter the exact version with two decimal digits, for example 4.51 or 10.01.'; return; }
      manualFirmware = version; storeWrite(consoleKey, version); selectFirmware('');
    }, 'secondary'); apply.id = 'set-firmware';
    const toggleLabel = element('label'), toggle = element('input'); toggle.type = 'checkbox'; toggle.id = 'show-incompatible';
    toggle.addEventListener('change', () => { state.showIncompatible = toggle.checked; renderCompatibility(); });
    toggleLabel.append(toggle, 'Show incompatible');
    const help = element('p', '', 'hint'); help.id = 'firmware-help';
    row.append(badge, label, apply, toggleLabel); panel.append(row, help); $('connection-help').after(panel);
    selectFirmware('');
  }
  function updateFirmwareUI() {
    const badge = $('firmware-badge'); if (!badge) return;
    badge.textContent = 'PS5 firmware: ' + (state.firmware || 'unknown');
    $('firmware-help').textContent = state.firmwareSource + '. ' + (state.firmware ? 'Known incompatible payloads are hidden. Unknown support stays visible and labelled.' : 'Choose the PS5 firmware when using a phone or PC. All items remain visible until it is known.');
    const automatic = state.firmwareSource !== 'Not detected' && state.firmwareSource !== 'Manually selected for this console';
    $('console-firmware').disabled = automatic; $('set-firmware').disabled = automatic;
    if (automatic) $('console-firmware').value = state.firmware;
  }
  function renderCompatibility() {
    if (!state.catalog) return;
    renderPayloads($('hen-catalog'), state.catalog.hens); renderPayloads($('mod-menu-catalog'), state.catalog.modMenus); renderPersonal();
  }
  function canSendName(name) {
    const items = state.catalog ? [...state.catalog.hens, ...state.catalog.modMenus].filter(item => item.name === name) : [];
    const allowed = items.every(item => compatibility(item) !== 'incompatible');
    if (!allowed) $('catalog-status').textContent = name + ' does not support firmware ' + state.firmware + '. Sending is disabled.';
    return allowed;
  }
  let favourites = storeRead('favourites', []), recents = storeRead('recents', []);
  if (!Array.isArray(favourites)) favourites = [];
  if (!Array.isArray(recents)) recents = [];
  function identity(item) { return {...item, key: item.key || item.path, kind: item.kind || (item.target ? 'cheat' : 'payload')}; }
  function favourite(item) {
    item = identity(item);
    const button = action('', () => {
      if (favourites.some(x => x.key === item.key)) favourites = favourites.filter(x => x.key !== item.key);
      else favourites.push(item);
      storeWrite('favourites', favourites); syncFavourites(); renderPersonal();
    }, 'favourite');
    button.dataset.favourite = item.key;
    updateFavourite(button); return button;
  }
  function updateFavourite(button) {
    const yes = favourites.some(x => x.key === button.dataset.favourite);
    button.textContent = button.className === 'cover-favourite' ? (yes ? '♥' : '♡') : yes ? '★ Favourite' : '☆ Favourite';
    button.setAttribute('aria-pressed', String(yes));
  }
  function syncFavourites() { document.querySelectorAll('[data-favourite]').forEach(updateFavourite); }
  function record(item) {
    item = {...identity(item), usedAt: Date.now()};
    if (item.kind === 'saved') setLoader(true, 'last send succeeded');
    recents = [item, ...recents.filter(x => x.key !== item.key)].slice(0, 12);
    storeWrite('recents', recents); renderPersonal();
  }
  function findCurrent(item) {
    if (item.kind === 'saved') return item;
    if (item.kind === 'game') return state.catalog && groupCheats(state.catalog.cheats).find(game => game.id === item.id);
    const all = state.catalog ? [...state.catalog.hens, ...state.catalog.modMenus, ...state.catalog.cheats] : [];
    return all.find(x => x.path === item.path);
  }
  function renderPersonal() {
    for (const [id, items] of [['favourites', favourites], ['recent-items', recents]]) {
      const container = $(id); container.textContent = '';
      if (!items.length) container.append(element('p', id === 'favourites' ? 'Choose ☆ Favourite on any file to save it here.' : 'Successful installs and payload sends appear here.', 'hint'));
      items.forEach(saved => {
        const item = findCurrent(saved), row = element('div', undefined, 'item');
        const info = element('div'); info.append(element('strong', saved.title || saved.name));
        info.append(element('div', saved.kind === 'game' ? saved.id : saved.kind === 'cheat' ? [saved.id, saved.version, saved.format].join(' · ') : saved.name, 'hint'));
        if (saved.usedAt) info.append(element('small', new Date(saved.usedAt).toLocaleString(), 'muted'));
        const actions = element('div', undefined, 'actions');
        if (item && compatibility(item) === 'incompatible') info.append(badge('Incompatible with ' + state.firmware, 'bad'));
        if (item && compatibility(item) !== 'incompatible') actions.append(action(saved.kind === 'game' ? 'View game' : saved.kind === 'cheat' ? 'Install' : 'Send', () => {
          if (saved.kind === 'game') { $('cheat-search').value = item.id; $('cheat-platform').value = ''; $('cheat-format').value = ''; $('cheat-version').value = ''; selectTab($('tab-cheats')); applyFilters(); }
          else if (saved.kind === 'saved') sendSaved(item); else startTransfer([item], item.title);
        }));
        else actions.append(element('span', 'No longer in catalogue', 'hint'));
        actions.append(favourite(saved)); row.append(info, actions); container.append(row);
      });
    }
  }
  async function response(url, options = {}, timeout = 30000) {
    const controller = new AbortController(), upstream = options.signal;
    const abort = () => controller.abort();
    if (upstream) { if (upstream.aborted) abort(); else upstream.addEventListener('abort', abort, {once: true}); }
    const timer = setTimeout(abort, timeout);
    try {
      const result = await fetch(url, {...options, signal: controller.signal});
      // Read the body before clearing the timer, so stalled downloads also time out.
      const blob = await result.blob();
      if (!result.ok) throw new Error('HTTP ' + result.status + ': ' + (await blob.text()).slice(0, 160));
      return blob;
    } catch (error) {
      if (controller.signal.aborted) throw new Error(upstream && upstream.aborted ? 'Cancelled' : 'Request timed out');
      throw error;
    } finally {
      clearTimeout(timer); if (upstream) upstream.removeEventListener('abort', abort);
    }
  }
  async function checkConnection() {
    $('manager-connection').textContent = 'Manager: checking…';
    $('check-connection').disabled = true;
    try {
      const data = JSON.parse(await (await response('/api/status', {cache: 'no-store'}, 5000)).text());
      state.preview = !!data.preview; state.manager = !data.preview;
      selectFirmware(data.firmware || data.systemFirmware || (data.console && data.console.firmware));
      $('manager-connection').textContent = data.preview ? 'Preview · no console' : 'Manager: connected';
      $('manager-connection').className = 'badge' + (data.preview ? '' : ' good');
      if (data.preview) {
        $('loader-connection').textContent = 'elfldr: preview only';
        $('connection-help').textContent = 'Browse and test controls here. Console installs and sends are disabled.';
      } else {
        $('connection-help').textContent = 'Manager reachable at ' + location.host + '. elfldr is verified when a payload is sent.';
        if (typeof data.elfldr === 'boolean') setLoader(data.elfldr, data.elfldr ? 'ready' : 'not listening');
        else if (!$('loader-connection').dataset.checked) $('loader-connection').textContent = 'elfldr: checked on send';
      }
    } catch (error) {
      state.manager = false;
      selectFirmware('');
      $('manager-connection').textContent = 'Manager: unreachable'; $('manager-connection').className = 'badge bad';
      $('loader-connection').textContent = 'elfldr: unknown'; $('loader-connection').className = 'badge';
      delete $('loader-connection').dataset.checked;
      $('connection-help').textContent = 'Reconnect to the PS5 network and reopen http://<PS5-IP>:8085. ' + error.message;
    } finally { $('check-connection').disabled = false; }
  }
  function setLoader(ok, message) {
    const badge = $('loader-connection'); badge.textContent = 'elfldr: ' + message;
    badge.className = 'badge' + (ok ? ' good' : ' bad'); badge.dataset.checked = 'true';
  }
  function filterCheats(files, filters) {
    const words = filters.query.toLowerCase().trim().split(/\s+/).filter(Boolean);
    return files.filter(file => (!filters.platform || file.platform === filters.platform) &&
      (!filters.format || file.format === filters.format) && (!filters.version || file.version.toLowerCase().includes(filters.version.toLowerCase().trim())) &&
      words.every(word => [file.title, file.id, ...(file.creators || [])].join(' ').toLowerCase().includes(word)));
  }
  function groupCheats(files) {
    const games = new Map();
    for (const file of files) {
      if (!games.has(file.id)) games.set(file.id, {title: file.title, id: file.id, platform: file.platform, cover: file.cover, files: []});
      games.get(file.id).files.push(file);
    }
    return [...games.values()].sort((a, b) => a.title.localeCompare(b.title) || a.id.localeCompare(b.id));
  }
  function applyFilters() {
    if (!state.catalog) return;
    const files = filterCheats(state.catalog.cheats, {query: $('cheat-search').value, platform: $('cheat-platform').value, format: $('cheat-format').value, version: $('cheat-version').value});
    state.groups = groupCheats(files); state.page = 0;
    $('cheat-count').textContent = state.groups.length.toLocaleString() + (state.groups.length === 1 ? ' game · ' : ' games · ') + files.length.toLocaleString() + ' matching files · ' + state.catalog.cheats.length.toLocaleString() + ' total files';
    renderGames();
  }
  function renderGames() {
    const container = $('cheat-games'); container.textContent = '';
    container.className = viewMode === 'list' ? 'game-list' : 'game-grid';
    const pages = Math.max(1, Math.ceil(state.groups.length / state.pageSize));
    if (!state.groups.length) container.append(element('p', 'No matching games. Try another title, ID, version or format.', 'empty'));
    state.groups.slice(state.page * state.pageSize, (state.page + 1) * state.pageSize).forEach((game, index) => {
      const box = element('article', undefined, 'cover-card');
      const summary = action('', () => toggleGame()); summary.className = 'cover-opener';
      summary.dataset.gameOpener = 'true'; summary.setAttribute('aria-expanded', 'false');
      summary.setAttribute('aria-label', game.title + ' · ' + game.platform + ' · ' + game.id + ' · Open versions');
      const cover = element('span', undefined, 'cover-wrap'), placeholder = element('span', game.title.split(/\s+/).slice(0, 2).map(word => word[0]).join('').toUpperCase(), 'cover-placeholder');
      placeholder.append(element('small', 'COVER UNAVAILABLE')); cover.append(placeholder);
      if (game.cover && /^Manager\/covers\/[A-Z]{4}\d{5}\.(jpg|png|webp)$/.test(game.cover)) {
        const image = element('img'); image.className = 'cover-image'; image.alt = ''; image.width = 320; image.height = 320;
        image.loading = 'lazy'; image.decoding = 'async'; image.referrerPolicy = 'no-referrer';
        image.src = repositoryBase + game.cover.split('/').map(encodeURIComponent).join('/');
        image.addEventListener('error', () => { image.hidden = true; }); cover.append(image);
      }
      cover.append(element('span', game.platform, 'cover-platform'));
      const formats = element('span', undefined, 'cover-formats');
      [...new Set(game.files.map(file => file.format))].sort().forEach(format => formats.append(element('span', format.toUpperCase(), 'cover-format'))); cover.append(formats);
      const versions = [...new Set(game.files.map(file => file.version))].sort(compareVersions);
      const meta = element('span', undefined, 'cover-meta');
      meta.append(element('span', game.id, 'cover-id'), element('strong', game.title, 'cover-title'));
      meta.append(element('span', versions.length + (versions.length === 1 ? ' version' : ' versions') + ' · Latest ' + versions[versions.length - 1], 'cover-count'));
      const creators = [...new Set(game.files.flatMap(file => file.creators || []))];
      meta.append(element('span', creators.join(', ') || 'Creator not specified', 'cover-creators'));
      summary.append(cover, meta);
      const body = element('div', undefined, 'game-body');
      body.hidden = true; body.id = 'game-detail-' + game.id; summary.setAttribute('aria-controls', body.id);
      function toggleGame(close = false) {
        const open = close ? false : body.hidden;
        body.hidden = !open; box.dataset.open = String(open); summary.setAttribute('aria-expanded', String(open));
        if (!open) { summary.focus(); return; }
        if (body.childNodes.length) return;
        for (const version of versions) {
          const files = game.files.filter(file => file.version === version);
          const heading = element('div', undefined, 'row');
          heading.append(element('h3', 'Game version ' + version), transferButton('Install version (' + files.length + ')', files, game.title + ' · ' + version));
          body.append(heading);
          files.sort((a, b) => a.format.localeCompare(b.format)).forEach(file => body.append(cheatFile(file)));
        }
        body.append(action('Close', () => toggleGame(true), 'secondary'));
      }
      summary.addEventListener('keydown', event => {
        if (event.key === 'Escape') { toggleGame(true); return; }
        if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key)) return;
        const buttons = [...container.querySelectorAll('[data-game-opener]')];
        const columns = viewMode === 'list' ? 1 : getComputedStyle(container).gridTemplateColumns.split(' ').filter(Boolean).length;
        const step = event.key === 'ArrowLeft' ? -1 : event.key === 'ArrowRight' ? 1 : event.key === 'ArrowUp' ? -columns : columns;
        const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : Math.max(0, Math.min(buttons.length - 1, index + step));
        event.preventDefault(); buttons[next].focus(); buttons[next].scrollIntoView({block:'nearest'});
      });
      const star = favourite({...game.files[0], key: 'game:' + game.id, kind: 'game', title: game.title});
      star.className = 'cover-favourite'; star.setAttribute('aria-label', 'Favourite ' + game.title);
      updateFavourite(star);
      box.append(summary, body, star); container.append(box);
    });
    $('cheat-page').textContent = 'Page ' + (state.page + 1) + ' of ' + pages;
    $('cheat-prev').disabled = state.page === 0; $('cheat-next').disabled = state.page + 1 >= pages;
  }
  function compareVersions(a, b) {
    const left = a.split('.').map(Number), right = b.split('.').map(Number);
    for (let i = 0; i < Math.max(left.length, right.length); i++) { const diff = (left[i] || 0) - (right[i] || 0); if (diff) return diff; }
    return a.localeCompare(b);
  }
  let viewMode = storeRead('viewMode', 'grid') === 'list' ? 'list' : 'grid';
  async function loadStyle() {
    const blob = await response(repositoryBase + 'Manager/library.css', {cache:'no-store'});
    let style = $('library-style');
    if (!style) { style = element('style'); style.id = 'library-style'; document.head.append(style); }
    style.textContent = await blob.text();
    document.documentElement.classList.add('library-wide');
    if (typeof navigator !== 'undefined' && /PlayStation 5/.test(navigator.userAgent)) document.documentElement.dataset.console = 'ps5';
  }
  function viewControls() {
    const row = element('div', undefined, 'view-controls');
    const grid = action('Grid', () => choose('grid')), list = action('List', () => choose('list'));
    function choose(mode) { viewMode = mode; storeWrite('viewMode', mode); grid.setAttribute('aria-pressed', String(mode === 'grid')); list.setAttribute('aria-pressed', String(mode === 'list')); renderGames(); }
    grid.setAttribute('aria-pressed', String(viewMode === 'grid')); list.setAttribute('aria-pressed', String(viewMode === 'list')); row.append(grid, list);
    $('cheat-games').before(row);
  }
  function badge(text, className = '') { return element('span', text, 'badge ' + className); }
  function transferButton(text, files, title) {
    const button = action(text, () => startTransfer(files, title));
    button.dataset.transfer = 'true'; button.disabled = !!(state.transfer && state.transfer.running); return button;
  }
  function cheatFile(file) {
    const row = element('article', undefined, 'file-entry');
    row.append(badge(file.format.toUpperCase()), badge(file.id + ' · v' + file.version), element('span', prettySize(file.size), 'muted'));
    row.append(element('p', 'Creator: ' + ((file.creators || []).join(', ') || 'Not specified in this file'), 'hint'));
    if (file.mods && file.mods.length) {
      const details = element('details'), summary = element('summary', 'Included cheats (' + file.mods.length + (file.mods.length === 30 ? '+' : '') + ')'), list = element('ul');
      file.mods.forEach(name => list.append(element('li', name))); details.append(summary, list); row.append(details);
    }
    if (file.notes) row.append(element('p', file.notes, 'hint'));
    row.append(element('p', '/data/etaHEN/cheats/' + file.target, 'path'));
    const actions = element('div', undefined, 'row'); actions.append(transferButton('Install to PS5', [file], file.title), favourite(file));
    row.append(actions); return row;
  }
  function safeLink(label, url) {
    if (!/^https:\/\/github\.com\//.test(url || '')) return element('span', '');
    const link = element('a', label); link.href = url; link.target = '_blank'; link.rel = 'noopener'; return link;
  }
  function renderPayloads(container, items) {
    container.textContent = '';
    const visible = items.filter(item => state.showIncompatible || compatibility(item) !== 'incompatible');
    const hidden = items.length - visible.length;
    if (hidden) container.append(element('p', hidden + ' incompatible item(s) hidden for firmware ' + state.firmware + '. Enable “Show incompatible” to inspect them.', 'compatibility-note'));
    if (!visible.length && !hidden) container.append(element('p', 'No payloads available yet.', 'hint'));
    visible.forEach(item => {
      const box = element('details', undefined, 'feature-card hen-card'), summary = element('summary', item.title), content = element('div', undefined, 'hen-card-content');
      content.append(element('p', item.description, 'hint'));
      const support = compatibility(item);
      content.append(badge(support === 'compatible' ? 'Supports firmware ' + state.firmware : support === 'incompatible' ? 'Incompatible with ' + state.firmware : 'Firmware compatibility unknown', support === 'compatible' ? 'good' : support === 'incompatible' ? 'bad' : ''));
      content.append(badge(item.author || 'Author not specified'), badge(item.release || 'Version not specified'), badge(prettySize(item.size)));
      if (item.firmware) {
        content.append(element('h3', 'Supported console firmware'));
        const list = element('ul');
        Object.entries(item.firmware).forEach(([series, versions]) => { const li = element('li', series + ' — '); versions.forEach(version => li.append(element('code', version), ' ')); list.append(li); });
        content.append(list);
      } else if (item.firmwareRanges) {
        content.append(element('h3','Supported console firmware'));
        item.firmwareRanges.forEach(range=>content.append(badge(range.min+' – '+range.max)));
        if (item.firmwareConditional && item.firmwareConditional.length) content.append(element('p','Conditional / unconfirmed on every console: '+item.firmwareConditional.join(', '),'hint'));
      } else content.append(badge('Console firmware: check project documentation'));
      if (item.gameCompatibility) { content.append(element('h3', 'Game compatibility')); const list = element('ul'); item.gameCompatibility.forEach(line => list.append(element('li', line))); content.append(list); }
      if (item.compatibilityNote) content.append(element('p', item.compatibilityNote, 'hint'));
      content.append(element('h3', 'Instructions'), element('p', item.instructions || 'Start a compatible HEN and elfldr, then send this payload.', 'hint'));
      const links = element('div', undefined, 'row'); links.append(safeLink('Project & documentation', item.project), safeLink('Releases / changelog', item.changelog)); content.append(links);
      content.append(element('p', item.name, 'path'));
      const actions = element('div', undefined, 'row');
      const send = transferButton('SEND', [item], item.title);
      send.dataset.incompatible = support === 'incompatible' ? 'true' : '';
      send.disabled = send.disabled || support === 'incompatible';
      actions.append(send, favourite(item), action('Close', () => { box.open = false; summary.focus(); }, 'secondary'));
      content.append(actions); box.append(summary, content); container.append(box);
    });
  }
  async function verify(blob, item) {
    if (item.size && blob.size !== item.size) throw new Error('Incomplete file: size does not match catalogue');
    if (!item.target) {
      const signature = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
      if (signature.length !== 4 || signature[0] !== 127 || signature[1] !== 69 || signature[2] !== 76 || signature[3] !== 70) throw new Error('Invalid ELF signature');
    }
    if (item.sha256 && typeof crypto !== 'undefined' && crypto.subtle) {
      const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
      const hash = Array.from(new Uint8Array(digest), x => x.toString(16).padStart(2, '0')).join('');
      if (hash !== item.sha256) throw new Error('File checksum does not match catalogue');
    }
  }
  function targetURL(item) {
    if (item.target) {
      if (!/^(json|mc4|shn)\//.test(item.target) || item.target.split('/').some(x => !x || x === '.' || x === '..')) throw new Error('Invalid cheat destination');
      return '/api/cheat-upload?path=' + encodeURIComponent(item.target);
    }
    if (!/^[A-Za-z0-9._-]+\.(elf|bin)$/i.test(item.name)) throw new Error('Invalid payload name');
    return '/api/upload?name=' + encodeURIComponent(item.name);
  }
  function updateTransfer() {
    const task = state.transfer; if (!task) return;
    $('transfer-panel').hidden = false; $('transfer-title').textContent = task.title;
    $('transfer-progress').max = Math.max(1, task.entries.length); $('transfer-progress').value = task.completed.length;
    const bytes = task.completed.reduce((sum, item) => sum + (item.size || 0), 0);
    $('transfer-status').textContent = task.completed.length + ' / ' + task.entries.length + ' completed · ' + prettySize(bytes) + ' · ' + (task.message || 'Working…');
    $('cancel-transfer').disabled = !task.running || task.cancelled;
    $('retry-transfer').hidden = task.running || task.completed.length === task.entries.length;
    const report = $('transfer-report'); report.textContent = '';
    // Limit visible failure rows to keep large collection reports responsive.
    task.failures.slice(0, 50).forEach(failure => report.append(element('p', failure.item.path + ': ' + failure.error)));
    if (!task.running) report.append(element('p', task.completed.length + ' succeeded; ' + task.failures.length + ' failed; ' + (task.entries.length - task.completed.length - task.failures.length) + ' not attempted.'));
    document.querySelectorAll('[data-transfer]').forEach(button => { button.disabled = task.running || button.dataset.incompatible === 'true'; });
  }
  async function startTransfer(items, title, resume = false) {
    if (state.transfer && state.transfer.running) { $('transfer-status').textContent = 'A transfer is already running. Wait or cancel it first.'; $('transfer-panel').scrollIntoView({block: 'nearest'}); return; }
    if (state.preview) { $('catalog-status').textContent = 'Preview only — open Manager at your PS5 address to install or send files.'; return; }
    if (!items.length) return;
    if (items.some(item => !item.target && !canSendName(item.name))) return;
    if (!resume && items.length > 1 && !confirm('Install ' + items.length + ' files to /data/etaHEN/cheats? Matching files will be replaced.')) return;
    const previous = state.transfer;
    const task = {entries: resume ? previous.entries : [...items], title, completed: resume ? [...previous.completed] : [], failures: [], running: true, cancelled: false, message: 'Downloading…', controller: new AbortController()};
    state.transfer = task; updateTransfer();
    $('transfer-panel').scrollIntoView({block: 'nearest', behavior: 'smooth'});
    let next = 0, stop = false;
    const workers = Array.from({length: Math.min(4, items.length)}, async () => {
      while (!stop && !task.cancelled && next < items.length) {
        const item = items[next++];
        try {
          const uploadURL = targetURL(item);
          const blob = await response(sourceURL(item.path), {cache: 'no-store', signal: task.controller.signal});
          await verify(blob, item);
          if (task.cancelled) break;
          task.message = 'Saving ' + (item.target || item.name) + '…'; updateTransfer();
          // Finish an accepted upload before stopping so cancellation cannot cut it short.
          await response(uploadURL, {method: item.target ? 'POST' : 'PUT', headers: requestHeaders(), body: blob}, 60000);
          if (!item.target) {
            task.message = 'Sending to elfldr…'; updateTransfer();
            try { await response('/api/send?name=' + encodeURIComponent(item.name), {method: 'POST', headers: requestHeaders()}, 30000); setLoader(true, 'last send succeeded'); }
            catch (error) { setLoader(false, 'send failed — check loader'); throw error; }
          }
          task.completed.push(item); record(item); task.message = task.cancelled ? 'Cancelling after current uploads…' : 'Installing…'; updateTransfer();
        } catch (error) {
          if (!task.cancelled) { task.failures.push({item, error: error.message}); stop = true; task.message = 'Finishing in-flight files after an error…'; updateTransfer(); }
        }
      }
    });
    await Promise.allSettled(workers);
    task.running = false;
    task.message = task.cancelled ? 'Cancelled. Completed files remain installed.' : task.completed.length === task.entries.length ? 'Complete. Files saved on PS5.' : 'Stopped. Retry remaining files to continue.';
    updateTransfer();
    if (task.completed.some(item => !item.target) && typeof refresh === 'function') refresh();
  }
  function cancelTransfer() {
    const task = state.transfer; if (!task || !task.running) return;
    task.cancelled = true; task.controller.abort(); task.message = 'Cancelling; accepted uploads will finish…'; updateTransfer();
  }
  function retryTransfer() {
    const task = state.transfer; if (!task || task.running) return;
    const done = new Set(task.completed.map(item => item.path));
    return startTransfer(task.entries.filter(item => !done.has(item.path)), task.title, true);
  }
  async function sendSaved(item) {
    if (!canSendName(item.name)) return;
    if (state.preview) { $('catalog-status').textContent = 'Preview only — no console connected.'; return; }
    if (state.transfer && state.transfer.running) { $('catalog-status').textContent = 'Wait for the current transfer to finish.'; return; }
    try { await response('/api/send?name=' + encodeURIComponent(item.name), {method: 'POST', headers: requestHeaders()}); setLoader(true, 'last send succeeded'); record(item); }
    catch (error) { setLoader(false, 'send failed'); $('catalog-status').textContent = error.message; }
  }
  async function init() {
    if (builtinCatalog) {
      state.catalog = {...builtinCatalog, cheats: []};
      renderPayloads($('hen-catalog'), builtinCatalog.hens); renderPayloads($('mod-menu-catalog'), builtinCatalog.modMenus);
    }
    try {
      const data = await loadCatalog();
      for (const key of ['hens', 'modMenus', 'cheats']) if (!Array.isArray(data[key])) throw new Error('Invalid catalogue');
      state.catalog = data;
      renderPayloads($('hen-catalog'), data.hens); renderPayloads($('mod-menu-catalog'), data.modMenus);
      $('download-all-cheats').disabled = false; applyFilters(); renderPersonal();
    } catch (error) { $('cheat-count').textContent = 'Catalogue unavailable. Check internet access and retry.'; $('catalog-status').textContent = error.message; }
  }
  let debounce;
  for (const id of ['cheat-search', 'cheat-platform', 'cheat-format', 'cheat-version']) $(id).addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(applyFilters, 150); });
  $('cheat-prev').addEventListener('click', () => { state.page = Math.max(0, state.page - 1); renderGames(); });
  $('cheat-next').addEventListener('click', () => { if ((state.page + 1) * state.pageSize < state.groups.length) state.page++; renderGames(); });
  $('download-all-cheats').dataset.transfer = 'true';
  $('download-all-cheats').addEventListener('click', () => state.catalog && startTransfer(state.catalog.cheats, 'Download all cheats'));
  $('cancel-transfer').addEventListener('click', cancelTransfer); $('retry-transfer').addEventListener('click', retryTransfer);
  $('check-connection').addEventListener('click', checkConnection);
  $('retry-library').addEventListener('click', () => { catalogPromise = null; init(); checkConnection(); loadStyle().catch(error => { $('catalog-status').textContent = error.message; }); });
  window.PSNLibrary = {record, favourite, filterCheats, groupCheats, verify, targetURL, startTransfer, cancelTransfer, retryTransfer, checkConnection, compatibility, selectFirmware, canSendName, state};
  firmwareControls();
  startLeafBackground();
  viewControls(); loadStyle().catch(error => { $('catalog-status').textContent = 'Cover layout unavailable. Retry library. ' + error.message; });
  renderPersonal(); checkConnection(); init();
  if (typeof refresh === 'function') refresh();
})();
